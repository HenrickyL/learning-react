import React from 'react'

export const Reports = () => {
    return (
        <div className="reports">
            <h1>Reports</h1>
            

        </div>
    )
}

export const ReportOne = () => {
    return (
        <div className="reports">
            <h1>Reports/Reports1</h1>
            

        </div>
    )
}
export const ReportTwo = () => {
    return (
        <div className="reports">
            <h1>Reports/Reports2</h1>
            

        </div>
    )
}
export const ReportThree = () => {
    return (
        <div className="reports">
            <h1>Reports/Reports3</h1>
            

        </div>
    )
}

