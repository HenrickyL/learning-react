# React Sidebar with Dropdown Menu - Create Sub Navigation


![Review](exemplo.gif)



## [Referência](https://www.youtube.com/watch?v=mN3P_rv8ad4)
