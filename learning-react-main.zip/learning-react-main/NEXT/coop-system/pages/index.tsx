import SignUp from "./components/login";

export default function Home() {
  return (
    <SignUp />
  )
}
