import SignUp from "./components/login";

export default function Home() {
  return (
    <h1>Olá mundo</h1>
  )
}
