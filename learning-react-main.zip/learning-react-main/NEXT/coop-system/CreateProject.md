```bash
yarn create-next-app nome_do_seu_projeto
```
* apaga a pasta style
* apaga conteúdo do index
* paga os itens da pasta public
* remove as dependencias do index e do _app
 * pagar pasta api


```bash
yarn add typescript @types/react @types/node -D 
```
instalar typescript e a integração
* alguns arquivos
