import React from 'react'

const Home = () => {

  return (
    <main>
      <section className="container flex flex--centro">
      <article className="cartao post">
        <h2 className="cartao__titulo">SUB</h2>
        <p className="cartao__texto">sub rota.</p>
      </article>
    </section>

    </main>
  )
}

export default Home
